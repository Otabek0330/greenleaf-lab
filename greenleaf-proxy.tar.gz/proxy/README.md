# GreenLeaf — Proxy server (10.0.50.30)
Run: edit `setup-proxy.sh` (paste step pubkey; confirm LAN_IF = your internal NIC),
then `sudo bash setup-proxy.sh`.
Squid forward proxy (:3128) + transparent intercept of routed port-80 (:3129), logs
everything to /var/log/squid/access.log (readable by `user`). Also enables IP
forwarding + NAT so this box is the env's default gateway and forwards traffic
onward to the firewall. Not attacked.
After the firewall exists, set THIS proxy's own default route to 10.0.50.1 and drop
its ens37 NAT. `squid -k parse` validates config; `systemctl status squid` to check.
