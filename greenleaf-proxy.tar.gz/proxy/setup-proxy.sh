#!/usr/bin/env bash
#
# GreenLeaf exercise — PROXY SERVER build (10.0.50.30)  —  run with: sudo bash setup-proxy.sh
# Squid forward+intercept proxy that LOGS all web traffic (forensic source), and
# acts as the default gateway for the env: it forwards everything onward to the
# firewall and masquerades. NOT attacked; teams can reach it and read squid logs.
#
set -euo pipefail
[[ $EUID -eq 0 ]] || { echo "Run with sudo."; exit 1; }

# ======== EDIT THESE ========
STEP_PUBKEY='PASTE_THE_STEP_PUBLIC_KEY_HERE'    # ssh-ed25519 AAAA... greenleaf-jump
LAN_IF='ens33'                                   # internal NIC on this proxy VM (check: ip -br a)
LAN_CIDR='10.0.50.0/24'
# ============================
[[ "$STEP_PUBKEY" == PASTE_* ]] && { echo "Paste STEP_PUBKEY first."; exit 1; }

echo "[*] 1/6  Defender account 'user' + step key..."
id user &>/dev/null || adduser --disabled-password --gecos "GreenLeaf Analyst" user
install -d -m 700 /home/user/.ssh
printf '%s\n' "$STEP_PUBKEY" > /home/user/.ssh/authorized_keys
chmod 600 /home/user/.ssh/authorized_keys; chown -R user:user /home/user/.ssh

echo "[*] 2/6  Harden sshd (key-only)..."
install -d -m 755 /etc/ssh/sshd_config.d
printf 'PasswordAuthentication no\nPubkeyAuthentication yes\nPermitRootLogin no\nKbdInteractiveAuthentication no\n' \
  > /etc/ssh/sshd_config.d/greenleaf.conf
systemctl reload ssh 2>/dev/null || systemctl reload sshd 2>/dev/null || true

echo "[*] 3/6  Install Squid + tools..."
export DEBIAN_FRONTEND=noninteractive
apt-get update -y
apt-get install -y squid iptables-persistent net-tools iproute2 lsof vim less

echo "[*] 4/6  Write Squid config (forward :3128, intercept :3129, log everything)..."
[[ -f /etc/squid/squid.conf.orig ]] || cp /etc/squid/squid.conf /etc/squid/squid.conf.orig
cat > /etc/squid/squid.conf <<CONF
acl localnet src ${LAN_CIDR}
acl SSL_ports port 443
acl Safe_ports port 80 443 21 70 210 1025-65535 280 488 591 777
acl CONNECT method CONNECT
http_access deny !Safe_ports
http_access deny CONNECT !SSL_ports
http_access allow localhost manager
http_access deny manager
http_access allow localnet
http_access allow localhost
http_access deny all
http_port 3128
http_port 3129 intercept
cache deny all
access_log /var/log/squid/access.log squid
coredump_dir /var/spool/squid
CONF
squid -k parse >/dev/null 2>&1 && echo "    squid config OK"
systemctl enable --now squid
systemctl restart squid

echo "[*] 5/6  Enable routing + NAT + transparent port-80 interception..."
printf 'net.ipv4.ip_forward=1\n' > /etc/sysctl.d/99-greenleaf.conf
sysctl -w net.ipv4.ip_forward=1 >/dev/null
# transparent-intercept port 80 from the LAN into Squid's intercept port
iptables -t nat -C PREROUTING -i "$LAN_IF" -p tcp --dport 80 -j REDIRECT --to-port 3129 2>/dev/null \
  || iptables -t nat -A PREROUTING -i "$LAN_IF" -p tcp --dport 80 -j REDIRECT --to-port 3129
# masquerade env traffic heading OFF the LAN (out whatever the proxy's gateway is)
iptables -t nat -C POSTROUTING -s "$LAN_CIDR" ! -d "$LAN_CIDR" -j MASQUERADE 2>/dev/null \
  || iptables -t nat -A POSTROUTING -s "$LAN_CIDR" ! -d "$LAN_CIDR" -j MASQUERADE
netfilter-persistent save >/dev/null 2>&1 || true

echo "[*] 6/6  Make squid logs readable by 'user'..."
usermod -aG adm user
# squid logs live under /var/log/squid (owner proxy). expose to adm/user:
chgrp -R adm /var/log/squid 2>/dev/null || true
chmod -R g+rX /var/log/squid 2>/dev/null || true
# keep new log files group-readable
sed -i 's#^access_log .*#access_log /var/log/squid/access.log squid#' /etc/squid/squid.conf
echo
echo "=================================================================="
echo " PROXY READY (10.0.50.30)."
echo "   Explicit proxy:    http://10.0.50.30:3128"
echo "   Transparent :80:   intercepted into Squid (logged) for routed hosts"
echo "   Access log:        /var/log/squid/access.log   (readable by 'user')"
echo "   Routing/NAT:       on — this box forwards env traffic to its gateway"
echo "   NOTE: set THIS proxy's default route to the firewall (10.0.50.1) in"
echo "         netplan once the firewall exists; until then its ens37 NAT is egress."
echo "=================================================================="
