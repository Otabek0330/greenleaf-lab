#!/usr/bin/env bash
#
# GreenLeaf exercise — FIREWALL build  —  run with: sudo bash setup-firewall.sh
# Dual-homed router/filter between the LAN (10.0.50.0/24) and the WAN/"internet"
# (203.0.113.0/24, where Kali/attacker lives). It ROUTES + LOGS all forwarded
# traffic (a forensic source) and FILTERS; teams get ROOT here and add DROP rules
# to contain the attacker.
#
# Teams: ssh firewall (key, as 'user') -> sudo -i  (enter user's password).
#
set -euo pipefail
[[ $EUID -eq 0 ]] || { echo "Run with sudo."; exit 1; }

# ======== EDIT THESE ========
STEP_PUBKEY='PASTE_THE_STEP_PUBLIC_KEY_HERE'    # ssh-ed25519 AAAA... greenleaf-jump
FW_USER_PASSWORD='GreenLeaf-FW-2026'             # teams get this (for sudo on the firewall)
LAN_IF='ens33';   LAN_CIDR='10.0.50.0/24'        # internal NIC (firewall is 10.0.50.1)
WAN_IF='ens37';   WAN_CIDR='203.0.113.0/24'      # "internet" NIC toward Kali (firewall is 203.0.113.1)
# ============================
[[ "$STEP_PUBKEY" == PASTE_* ]] && { echo "Paste STEP_PUBKEY first."; exit 1; }

echo "[*] 1/7  Defender account 'user' — WITH password + full sudo (teams get root here)..."
id user &>/dev/null || adduser --disabled-password --gecos "GreenLeaf Analyst" user
echo "user:${FW_USER_PASSWORD}" | chpasswd
usermod -aG sudo user
install -d -m 700 /home/user/.ssh
printf '%s\n' "$STEP_PUBKEY" > /home/user/.ssh/authorized_keys
chmod 600 /home/user/.ssh/authorized_keys; chown -R user:user /home/user/.ssh

echo "[*] 2/7  Harden sshd (key-only login; escalate with sudo+password)..."
install -d -m 755 /etc/ssh/sshd_config.d
printf 'PasswordAuthentication no\nPubkeyAuthentication yes\nPermitRootLogin no\nKbdInteractiveAuthentication no\n' \
  > /etc/ssh/sshd_config.d/greenleaf.conf
systemctl reload ssh 2>/dev/null || systemctl reload sshd 2>/dev/null || true

echo "[*] 3/7  Install tools..."
export DEBIAN_FRONTEND=noninteractive
apt-get update -y
apt-get install -y iptables iptables-persistent rsyslog net-tools iproute2 lsof vim less

echo "[*] 4/7  Enable IP forwarding (router between LAN and WAN)..."
printf 'net.ipv4.ip_forward=1\n' > /etc/sysctl.d/99-greenleaf.conf
sysctl -w net.ipv4.ip_forward=1 >/dev/null

echo "[*] 5/7  Route firewall logs to their own file (forensic source)..."
cat > /etc/rsyslog.d/10-greenleaf-fw.conf <<'RS'
# send kernel iptables messages tagged "GL-" to their own file, and stop
:msg, startswith, "GL-"   -/var/log/greenleaf-firewall.log
& stop
RS
touch /var/log/greenleaf-firewall.log
chgrp adm /var/log/greenleaf-firewall.log; chmod 640 /var/log/greenleaf-firewall.log
usermod -aG adm user                      # 'user' can read the firewall log
systemctl restart rsyslog

echo "[*] 6/7  Install the baseline iptables ruleset..."
iptables -F; iptables -X 2>/dev/null || true
iptables -t nat -F 2>/dev/null || true
iptables -P INPUT DROP
iptables -P FORWARD DROP
iptables -P OUTPUT ACCEPT

# --- traffic TO the firewall itself ---
iptables -A INPUT -i lo -j ACCEPT
iptables -A INPUT -m conntrack --ctstate ESTABLISHED,RELATED -j ACCEPT
iptables -A INPUT -s "$LAN_CIDR" -p tcp --dport 22 -j ACCEPT      # ssh from the LAN (step/user)
iptables -A INPUT -p icmp -j ACCEPT

# --- traffic ROUTED through the firewall (LAN <-> WAN) ---
iptables -A FORWARD -m conntrack --ctstate ESTABLISHED,RELATED -j ACCEPT
# log every NEW flow crossing the firewall (both directions) BEFORE allowing it
iptables -A FORWARD -m conntrack --ctstate NEW -j LOG --log-prefix "GL-FWD-NEW " --log-level 6
# baseline connectivity so the environment runs (teams INSERT drops above this to contain)
iptables -A FORWARD -s "$LAN_CIDR" -d "$WAN_CIDR" -j ACCEPT
iptables -A FORWARD -s "$WAN_CIDR" -d "$LAN_CIDR" -j ACCEPT
# anything else that reaches here is about to be dropped by policy — log it
iptables -A FORWARD -j LOG --log-prefix "GL-FWD-DROP " --log-level 6

netfilter-persistent save >/dev/null 2>&1 || true

echo "[*] 7/7  Done."
echo
echo "=================================================================="
echo " FIREWALL READY (LAN 10.0.50.1 <-> WAN 203.0.113.1)."
echo "   Teams:   ssh firewall  (key, as user)  ->  sudo -i   (pw: ${FW_USER_PASSWORD})"
echo "   Log:     /var/log/greenleaf-firewall.log   (readable by user; GL-FWD-NEW / -DROP)"
echo "   Contain example (teams run as root):"
echo "       iptables -I FORWARD 1 -d 203.0.113.10 -j DROP    # cut the attacker"
echo "       iptables -I FORWARD 1 -s 203.0.113.10 -j DROP"
echo "   Persist a team's rules:  netfilter-persistent save"
echo "------------------------------------------------------------------"
echo " NICs required: ${LAN_IF}=10.0.50.1/24  and  ${WAN_IF}=203.0.113.1/24 (set in netplan)."
echo "=================================================================="
