# GreenLeaf — Firewall (LAN 10.0.50.1 <-> WAN 203.0.113.1)
Dual-homed. Set two NICs in netplan first:
  ens33: 10.0.50.1/24   (LAN)        ens37: 203.0.113.1/24  (WAN, toward Kali)
Then: edit setup-firewall.sh (step pubkey; confirm LAN_IF/WAN_IF; set FW_USER_PASSWORD),
and `sudo bash setup-firewall.sh`.

- Routes + LOGS all forwarded traffic; teams get ROOT (user + sudo + password).
- Access: ssh firewall (key, as user) -> sudo -i (enter FW_USER_PASSWORD).
- Log: /var/log/greenleaf-firewall.log  (GL-FWD-NEW = new flows, GL-FWD-DROP = blocked).
- Teams contain by inserting DROPs, e.g.:
    sudo iptables -I FORWARD 1 -d 203.0.113.10 -j DROP
    sudo netfilter-persistent save
