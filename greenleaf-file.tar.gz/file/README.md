# GreenLeaf — File server (10.0.50.40)
Samba department shares holding the generative critical data (Day-2 exfil +
ransomware target). Run: edit setup-file.sh (step pubkey), `sudo bash setup-file.sh`.

Shares (//10.0.50.40/<share>):
  finance     company accounts, payroll (salaries+bank), transactions   <- Day-2 target
  hr          full employee files (passport, address, salary, bank)
  sales       merchant settlement/bank details
  support     customer contact + tickets
  management  exec compensation, board minutes, strategy (CONFIDENTIAL)

SMB credentials (organizer reference — NOT given to participants, except j_smith's
is the one "stored on the workstation" that the Day-2 malware uses):
  j_smith        GreenLeaf!Fin2024     -> finance  (the Day-2 credential)
  a_karimova     Hr!Green2024          -> hr
  d_usmonov      Sales!Green24         -> sales
  m_toshpulatov  Supp0rt!Green24       -> support
  b_ismoilov     Mgmt!Green2024        -> management
  backup_svc     backup123             -> ALL shares (OVER-PRIVILEGED, weak pw = planted finding)

Forensics: /var/log/samba/audit.log logs every file open/read/write/rename/unlink
(user|client_ip|machine|share) — teams see exactly which files were read/dumped and
when the ransomware rewrote them. Readable by 'user'. Also /var/log/samba/log.*.

At attack time (built later): the Day-2 chain uses j_smith's cred for finance, a
simulated Samba RCE for all-share access, then creates the backdoor user
g00dJ0bF1nd1ngME + ~1000 noise accounts and the ransomware. Those noise/backdoor
accounts are NOT protected, so teams can remove them with grn; the legit staff +
backup_svc accounts ARE protected.
