#!/usr/bin/env bash
#
# GreenLeaf exercise — FILE SERVER build (10.0.50.40)  —  run with: sudo bash setup-file.sh
# Samba department shares holding the generative critical business data (Day-2
# exfil + ransomware target). Standard Samba; the Day-2 "Samba RCE" is simulated
# at the evidence level (deterministic across pods). File access is AUDITED so
# teams can see which files the malware read/dumped.
#
# Accounts: cbu = setup/admin (untouched); user = defender (key-only + grn);
#           Samba users below are the department staff + one OVER-PRIVILEGED
#           service account (planted finding).
#
set -euo pipefail
[[ $EUID -eq 0 ]] || { echo "Run with sudo."; exit 1; }
HERE="$(cd "$(dirname "$0")" && pwd)"

# ======== EDIT THESE ========
STEP_PUBKEY='PASTE_THE_STEP_PUBLIC_KEY_HERE'    # ssh-ed25519 AAAA... greenleaf-jump
APPLY_SUDO_LAYER="yes"
# ============================
[[ "$STEP_PUBKEY" == PASTE_* ]] && { echo "Paste STEP_PUBKEY first."; exit 1; }

# Samba users -> passwords  (j_smith's is the credential the Day-2 malware uses)
declare -A SMB=(
  [j_smith]='GreenLeaf!Fin2024'
  [a_karimova]='Hr!Green2024'
  [d_usmonov]='Sales!Green24'
  [m_toshpulatov]='Supp0rt!Green24'
  [b_ismoilov]='Mgmt!Green2024'
  [backup_svc]='backup123'
)

echo "[*] 1/9  Defender account 'user' + step key..."
id user &>/dev/null || adduser --disabled-password --gecos "GreenLeaf Analyst" user
install -d -m 700 /home/user/.ssh
printf '%s\n' "$STEP_PUBKEY" > /home/user/.ssh/authorized_keys
chmod 600 /home/user/.ssh/authorized_keys; chown -R user:user /home/user/.ssh

echo "[*] 2/9  Harden sshd (key-only)..."
install -d -m 755 /etc/ssh/sshd_config.d
printf 'PasswordAuthentication no\nPubkeyAuthentication yes\nPermitRootLogin no\nKbdInteractiveAuthentication no\n' \
  > /etc/ssh/sshd_config.d/greenleaf.conf
systemctl reload ssh 2>/dev/null || systemctl reload sshd 2>/dev/null || true

echo "[*] 3/9  Install Samba + tools..."
export DEBIAN_FRONTEND=noninteractive
apt-get update -y
apt-get install -y samba samba-vfs-modules rsyslog net-tools iproute2 lsof vim less tar

echo "[*] 4/9  Create the smb group + department/service accounts..."
groupadd -f smbgrp
for u in "${!SMB[@]}"; do
  id "$u" &>/dev/null || useradd --system -M -s /usr/sbin/nologin -g smbgrp "$u"
done
usermod -aG smbgrp user     # defender can read the shares for forensics

echo "[*] 5/9  Set Samba passwords..."
for u in "${!SMB[@]}"; do
  printf '%s\n%s\n' "${SMB[$u]}" "${SMB[$u]}" | smbpasswd -s -a "$u" >/dev/null
  smbpasswd -e "$u" >/dev/null 2>&1 || true
done

echo "[*] 6/9  Deploy the shares + permissions..."
install -d -m 2770 /srv/samba
for d in finance hr sales support management; do
  install -d -m 2770 "/srv/samba/$d"
  cp -r "$HERE/shares/$d/." "/srv/samba/$d/"
done
chown -R root:smbgrp /srv/samba
find /srv/samba -type d -exec chmod 2770 {} \;
find /srv/samba -type f -exec chmod 0660 {} \;

echo "[*] 7/9  Write smb.conf (per-dept shares + full_audit access logging)..."
[[ -f /etc/samba/smb.conf.orig ]] || cp /etc/samba/smb.conf /etc/samba/smb.conf.orig
cat > /etc/samba/smb.conf <<'CONF'
[global]
   workgroup = GREENLEAF
   server string = GreenLeaf File Server
   security = user
   map to guest = never
   server role = standalone server
   log file = /var/log/samba/log.%m
   max log size = 1000
   # --- audit every file access (forensic source) ---
   vfs objects = full_audit
   full_audit:prefix = %u|%I|%m|%S
   full_audit:success = connect disconnect opendir mkdir open read pread write pwrite rename unlink
   full_audit:failure = connect
   full_audit:facility = local5
   full_audit:priority = notice

[finance]
   path = /srv/samba/finance
   valid users = j_smith, backup_svc
   write list = j_smith
   read only = no
   force group = smbgrp
   create mask = 0660
   directory mask = 2770

[hr]
   path = /srv/samba/hr
   valid users = a_karimova, backup_svc
   write list = a_karimova
   read only = no
   force group = smbgrp
   create mask = 0660
   directory mask = 2770

[sales]
   path = /srv/samba/sales
   valid users = d_usmonov, backup_svc
   write list = d_usmonov
   read only = no
   force group = smbgrp
   create mask = 0660
   directory mask = 2770

[support]
   path = /srv/samba/support
   valid users = m_toshpulatov, backup_svc
   write list = m_toshpulatov
   read only = no
   force group = smbgrp
   create mask = 0660
   directory mask = 2770

[management]
   path = /srv/samba/management
   valid users = b_ismoilov, backup_svc
   write list = b_ismoilov
   read only = no
   force group = smbgrp
   create mask = 0660
   directory mask = 2770
CONF
testparm -s >/dev/null 2>&1 && echo "    smb.conf OK"

echo "[*] 8/9  Route Samba audit to its own log (readable by 'user')..."
cat > /etc/rsyslog.d/20-greenleaf-samba.conf <<'RS'
local5.*   -/var/log/samba/audit.log
& stop
RS
mkdir -p /var/log/samba
touch /var/log/samba/audit.log
chown syslog:adm /var/log/samba/audit.log 2>/dev/null || chgrp adm /var/log/samba/audit.log
chmod 640 /var/log/samba/audit.log
usermod -aG adm user
systemctl restart rsyslog
systemctl enable --now smbd nmbd
systemctl restart smbd nmbd

echo "[*] 9/9  Exercise privilege layer (grn + scoped sudo)..."
if [[ "$APPLY_SUDO_LAYER" == "yes" ]]; then
  install -d -m 755 /opt/greenleaf
  install -o root -g root -m 0755 "$HERE/grn-ir-tool.sh" /opt/greenleaf/grn
  ln -sf /opt/greenleaf/grn /usr/local/bin/grn
  install -o root -g root -m 0440 "$HERE/sudoers-greenleaf-user" /etc/sudoers.d/greenleaf-user
  visudo -cf /etc/sudoers.d/greenleaf-user >/dev/null && echo "    sudoers OK"
fi

echo
echo "=================================================================="
echo " FILE SERVER READY (10.0.50.40)."
echo "   Shares: //10.0.50.40/{finance,hr,sales,support,management}"
echo "   Finance is the Day-2 target; j_smith's cred is what the malware uses."
echo "   Audit log (forensic): /var/log/samba/audit.log  (readable by user)"
echo "   From step:  ssh file"
echo " PLANTED FINDING: 'backup_svc' can read EVERY share (over-privileged),"
echo "   with a weak password. Teams should flag it."
echo "=================================================================="
