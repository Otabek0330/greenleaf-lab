#!/usr/bin/env bash
# Run on the WEB server:  sudo bash update-web-login.sh
# Replaces /var/www/greenleaf/login.php so the four logins redirect to the
# service dashboards (admin/client/merchant/employee). Nothing else changes.
set -euo pipefail
[[ $EUID -eq 0 ]] || { echo "Run with sudo."; exit 1; }
DOCROOT=/var/www/greenleaf
cat > "$DOCROOT/login.php" <<'PHP'
<?php
// GreenLeaf login handler — front-end simulation (no database).
// Valid credentials are name/name; each opens the matching dashboard on the
// SERVICE server. admin/admin opens the admin dashboard (all-role overview) and
// is the credential the Day-1 brute force targets. The "defaced" version of this
// file (which echoes input) is deployed by the attacker scripts later.
$SERVICE = 'http://10.0.50.20';   // service dashboards (swap to a hostname after DNS if you like)
$map = [
    'admin'    => '/index.html',     // admin dashboard: client/merchant/employee overview
    'client'   => '/client.html',
    'merchant' => '/merchant.html',
    'employee' => '/employee.html',
];
$u = $_POST['username'] ?? '';
$p = $_POST['password'] ?? '';
if (isset($map[$u]) && $p === $u) {          // cred is name/name
    header('Location: ' . $SERVICE . $map[$u]);
    exit;
}
http_response_code(401);
?>
<!doctype html><html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Sign in failed — GreenLeaf</title>
<link rel="stylesheet" href="/assets/css/main.css">
<link rel="icon" type="image/png" href="/assets/img/favicon.png"></head>
<body class="centered">
<div class="card login">
  <a href="/" class="logo-link"><img class="logo-full" src="/assets/img/logo-full.png" alt="GreenLeaf — Online Marketplace"></a>
  <h1>Sign in failed</h1>
  <p class="muted">The username or password is incorrect.</p>
  <a class="btn btn-primary wide" href="/login.html">Try again</a>
</div>
</body></html>
PHP
chown web:webadmin "$DOCROOT/login.php" 2>/dev/null || true
chmod 664 "$DOCROOT/login.php"
php -l "$DOCROOT/login.php"
echo "login.php updated. Try:  admin/admin, client/client, merchant/merchant, employee/employee"
echo "Each redirects to http://10.0.50.20/<role> on the service server."
