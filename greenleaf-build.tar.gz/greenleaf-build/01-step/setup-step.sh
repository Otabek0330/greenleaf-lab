#!/usr/bin/env bash
#
# GreenLeaf exercise — STEP SERVER (jump host / bastion) setup
# Run as root ON THE STEP VM (10.0.50.2).
#
# What this does:
#   1. Creates the 'step' login account teams use (give it the per-team password).
#   2. Generates the passphrase-less jump keypair.
#   3. Installs the PRIVATE key for BOTH root and step (either can jump onward).
#   4. Writes an ssh client config so `ssh web`, `ssh service`, ... just work.
#   5. Leaves the PUBLIC key at /root/greenleaf_jump.pub to copy to every server.
#
# The step server's own sshd keeps PASSWORD auth ON — teams log in here with the
# per-team password. Only the ONWARD hop to the environment servers is key-only.
#
set -euo pipefail
[[ $EUID -eq 0 ]] || { echo "Run as root."; exit 1; }

KEY=/root/.ssh/greenleaf_jump
STEP_USER=step

echo "[*] 1/5  Creating '$STEP_USER' login account (teams log in as this)..."
if ! id "$STEP_USER" &>/dev/null; then
  adduser --disabled-password --gecos "GreenLeaf Jump" "$STEP_USER"
fi
usermod -aG sudo "$STEP_USER"            # teams may have root on the step box
echo "    -> set the per-team password now:  passwd $STEP_USER"

echo "[*] 2/5  Generating the jump keypair (passphrase-less)..."
install -d -m 700 /root/.ssh
if [[ ! -f $KEY ]]; then
  ssh-keygen -t ed25519 -N "" -C "greenleaf-jump" -f "$KEY"
fi

echo "[*] 3/5  Installing the PRIVATE key for root and $STEP_USER..."
install -d -m 700 "/home/$STEP_USER/.ssh"
cp "$KEY"       "/home/$STEP_USER/.ssh/greenleaf_jump"
cp "$KEY.pub"   "/home/$STEP_USER/.ssh/greenleaf_jump.pub"
chmod 600 "/home/$STEP_USER/.ssh/greenleaf_jump" "$KEY"
chown -R "$STEP_USER:$STEP_USER" "/home/$STEP_USER/.ssh"

echo "[*] 4/5  Writing ssh client config (shortcuts to every server)..."
write_cfg () {   # $1 = home dir, $2 = owner
  cat > "$1/.ssh/config" <<CFG
# GreenLeaf environment — jump shortcuts. Usage from the step box:  ssh web
Host web      ; HostName 10.0.50.10
Host service  ; HostName 10.0.50.20
Host proxy    ; HostName 10.0.50.30
Host file     ; HostName 10.0.50.40
Host security ; HostName 10.0.50.50
Host dns      ; HostName 10.0.50.5
Host firewall ; HostName 10.0.50.1
Host web service proxy file security dns firewall
    User user
    IdentityFile ~/.ssh/greenleaf_jump
    StrictHostKeyChecking accept-new
CFG
  # the "Host x ; HostName y" shorthand above is not valid ssh syntax on one line;
  # rewrite into proper stanzas:
  python3 - "$1/.ssh/config" <<'PY'
import sys,re
p=sys.argv[1]
hosts={"web":"10.0.50.10","service":"10.0.50.20","proxy":"10.0.50.30",
       "file":"10.0.50.40","security":"10.0.50.50","dns":"10.0.50.5",
       "firewall":"10.0.50.1"}
out=["# GreenLeaf environment — jump shortcuts. From the step box:  ssh web\n"]
for h,ip in hosts.items():
    out.append(f"Host {h}\n    HostName {ip}\n    User user\n"
               f"    IdentityFile ~/.ssh/greenleaf_jump\n"
               f"    StrictHostKeyChecking accept-new\n\n")
open(p,"w").write("".join(out))
PY
  chmod 600 "$1/.ssh/config"; chown "$2:$2" "$1/.ssh/config"
}
write_cfg /root root
write_cfg "/home/$STEP_USER" "$STEP_USER"

echo "[*] 5/5  Exporting the PUBLIC key for distribution..."
cp "$KEY.pub" /root/greenleaf_jump.pub
echo
echo "=================================================================="
echo " STEP SERVER READY."
echo " Public key to install on EVERY environment server (as user's"
echo " authorized_keys) is at:  /root/greenleaf_jump.pub"
echo "------------------------------------------------------------------"
cat /root/greenleaf_jump.pub
echo "=================================================================="
echo " Remember:  passwd $STEP_USER   (set the per-team password)"
