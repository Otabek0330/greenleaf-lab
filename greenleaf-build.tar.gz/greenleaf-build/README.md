# GreenLeaf exercise — environment build (step 1: STEP, step 2: WEB)

Build order per pod: **step server first** (it mints the SSH key every other server
trusts), then **web**, then the rest. This package covers **step** and **web**.

## Conventions baked in
- Defender account on every environment server is **`user`** (non-root), reached
  **only** by jumping through the step server with the key.
- **`user` cannot become root.** It gets scoped remediation rights through one
  guarded tool, **`grn`** (see below). Root is the team's only on the **firewall**.
- Attacker artifacts (shells, backdoor users, cron, dropped files) are **non-root**,
  so `grn` can remove them; the **reporting agent runs as root**, so teams can't.

---

## 1. STEP server (10.0.50.2)  —  `01-step/setup-step.sh`
Run as root on the step VM:
1. `scp` / copy `setup-step.sh` to the step VM.
2. `sudo ./setup-step.sh`
3. `sudo passwd step`  → set this team's per-team password (what they log in with).
4. Copy the printed **public key** (also saved to `/root/greenleaf_jump.pub`) — you
   paste it into every environment server's `setup-*.sh`.

What it does: creates the `step` login (sudo-capable), generates the passphrase-less
jump keypair, installs the **private** key for root and `step`, writes an ssh config
so `ssh web` / `ssh service` / … work, and exports the **public** key for the servers.

> The step box keeps password SSH **on** (teams log in here with the per-team
> password). Only the onward hop to the environment servers is key-only.

---

## 2. WEB server (10.0.50.10)  —  `02-web/setup-web.sh`
1. Copy the whole `02-web/` folder to the web VM (e.g. `/root/02-web`).
2. Edit `setup-web.sh` → paste the step **public key** into `STEP_PUBKEY='...'`.
3. `sudo ./setup-web.sh`

What it does, in order: creates `user`; installs the step public key into
`user`'s `authorized_keys`; hardens sshd (**key-only, no passwords, no root**);
installs the **`grn`** IR tool + sudoers policy; adds `user` to `adm` (log read);
installs Apache + PHP + participant tools (wget, curl, net-tools, lsof, vim…);
deploys the site to `/var/www/greenleaf` (group-writable by `user` for restore);
stages the recovery backups at `/opt/greenleaf/backups`; enables the vhost.

After it runs:
- Site: `http://10.0.50.10/` (and `http://greenleaf.com/` once DNS is up).
- Login: **admin / admin** → `/dashboard.html` (the only valid credential; cosmetic).
- Defender access: from the step box, `ssh web` (as `user`, key-only).
- IR tool: `sudo grn help`.

### The `grn` IR tool (scoped remediation)
`user` runs these via sudo; the tool enforces the guardrails:
- `sudo grn kill <pid>` — kill a **non-root** process (a reverse shell). Refuses
  root-owned PIDs (so the agent is safe) and PID 1.
- `sudo grn deluser <name>` — remove a backdoor account (`system`, the Day-2 noise
  users). Refuses `root`, `user`, and the service accounts.
- `sudo grn rmfile <path>` — delete a dropped file. Refuses system dirs.
- `sudo grn cronclear <user>` — wipe an attacker crontab. Refuses protected users.

Edit the protected lists at the top of `/opt/greenleaf/grn` to match your final
account/agent names (set `AGENT_NAME` to the reporting agent's process/unit name).

---

## IMPORTANT — how the Apache CVE-2021-41773 step is handled
The setup installs the **distro's current, patched Apache** and serves the
front-end on it. Do **not** expose a genuinely exploitable Apache 2.4.49 across
every pod — for this exercise the unauthenticated-RCE step is best **simulated**:

- The attacker scripts (built later, on Kali) **generate the authentic evidence**
  — the path-traversal request lines in the web access log, the follow-on command
  output — and the **effect** (the reverse shell, the dropped files) is placed
  through the organizers' control channel. Teams see exactly the same logs and
  artifacts to detect and respond to.
- This is **deterministic** (identical in all pods, nothing flaky to exploit live)
  and keeps the lab from running real remotely-exploitable services.

If you specifically want a genuinely vulnerable instance instead, that is a
separate decision — tell me and we'll scope it deliberately. The front-end,
hardening, user model and IR tooling above are identical either way.

---

## Brand assets
The company logo lives at `02-web/site/assets/img/`:
- `logo-mark.png`  — cart+leaf icon only (nav bars, compact spots), transparent bg
- `logo-full.png`  — full stacked logo incl. wordmark (login/error cards), transparent bg
- `favicon.png`    — 64×64 favicon

Pages use: the **mark + "GreenLeaf"** text in nav bars; the **full logo** on the
login and failure cards; the favicon site-wide. Reuse these same files for the
service server's dashboards and the webmail UI so the branding is consistent.
