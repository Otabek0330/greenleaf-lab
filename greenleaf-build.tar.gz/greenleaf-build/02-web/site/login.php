<?php
// GreenLeaf login handler — front-end simulation only, no real database.
// The ONLY valid credential is admin / admin (cosmetic: it just opens the
// static dashboard). Everything else fails. (The exercise's "defaced" version
// of this file, which echoes input, is deployed by the attacker scripts later.)
$u = $_POST['username'] ?? '';
$p = $_POST['password'] ?? '';
if ($u === 'admin' && $p === 'admin') {
    header('Location: /dashboard.html');
    exit;
}
http_response_code(401);
?>
<!doctype html><html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Sign in failed — GreenLeaf</title>
<link rel="stylesheet" href="/assets/css/main.css">
<link rel="icon" type="image/png" href="/assets/img/favicon.png"></head>
<body class="centered">
<div class="card login">
  <a href="/" class="logo-link"><img class="logo-full" src="/assets/img/logo-full.png" alt="GreenLeaf — Online Marketplace"></a>
  <h1>Sign in failed</h1>
  <p class="muted">The username or password is incorrect.</p>
  <a class="btn btn-primary wide" href="/login.html">Try again</a>
</div>
</body></html>
