GreenLeaf recovery backups — PARTIAL known-good source.
Contains only the landing page and the login page (and their css/js).
It is NOT a full copy of the site: do not bulk-copy this tree over the web root
or the site will break. Restore the specific defaced page's files to their
correct locations under the web root (/var/www/greenleaf).

  landing_page/index.html      -> /var/www/greenleaf/index.html
  landing_page/css/main.css    -> /var/www/greenleaf/assets/css/main.css
  landing_page/js/main.js      -> /var/www/greenleaf/assets/js/main.js
  login_page/login.html        -> /var/www/greenleaf/login.html
