#!/usr/bin/env bash
#
# GreenLeaf exercise — WEB SERVER setup
# Run as root ON THE WEB VM (10.0.50.10), after you have copied this whole
# 02-web/ folder onto the box (e.g. to /root/02-web).
#
# Order of operations:
#   1. Create the defender account 'user'.
#   2. Install the step server's PUBLIC key into user's authorized_keys.
#   3. Harden sshd: key-only, no passwords, no root login.
#   4. Install the scoped IR tool 'grn' + sudoers policy (remediation only).
#   5. Give 'user' read access to the logs (adm group).
#   6. Install Apache + PHP + the tools participants may need.
#   7. Deploy the GreenLeaf site; stage the recovery backups.
#
# BEFORE RUNNING: paste the step public key into the variable below
# (the line printed by setup-step.sh, or the contents of greenleaf_jump.pub).
#
set -euo pipefail
[[ $EUID -eq 0 ]] || { echo "Run as root."; exit 1; }
HERE="$(cd "$(dirname "$0")" && pwd)"

STEP_PUBKEY='PASTE_THE_STEP_PUBLIC_KEY_HERE'   # <-- ssh-ed25519 AAAA... greenleaf-jump

[[ "$STEP_PUBKEY" == PASTE_* ]] && { echo "Edit setup-web.sh and paste STEP_PUBKEY first."; exit 1; }

echo "[*] 1/7  Creating defender account 'user'..."
if ! id user &>/dev/null; then
  adduser --disabled-password --gecos "GreenLeaf Analyst" user
fi

echo "[*] 2/7  Installing step public key for 'user'..."
install -d -m 700 /home/user/.ssh
printf '%s\n' "$STEP_PUBKEY" > /home/user/.ssh/authorized_keys
chmod 600 /home/user/.ssh/authorized_keys
chown -R user:user /home/user/.ssh

echo "[*] 3/7  Hardening sshd (key-only, no password, no root)..."
install -d -m 755 /etc/ssh/sshd_config.d
cat > /etc/ssh/sshd_config.d/greenleaf.conf <<'SSHD'
PasswordAuthentication no
PubkeyAuthentication yes
PermitRootLogin no
KbdInteractiveAuthentication no
SSHD
systemctl reload ssh 2>/dev/null || systemctl reload sshd 2>/dev/null || service ssh reload

echo "[*] 4/7  Installing scoped IR tool + sudoers..."
install -d -m 755 /opt/greenleaf
install -o root -g root -m 0755 "$HERE/grn-ir-tool.sh" /opt/greenleaf/grn
install -o root -g root -m 0440 "$HERE/sudoers-greenleaf-user" /etc/sudoers.d/greenleaf-user
visudo -cf /etc/sudoers.d/greenleaf-user >/dev/null && echo "    sudoers OK"
ln -sf /opt/greenleaf/grn /usr/local/bin/grn   # so `sudo grn ...` resolves

echo "[*] 5/7  Giving 'user' read access to logs..."
usermod -aG adm user          # /var/log readable (incl. apache via adm on Ubuntu)

echo "[*] 6/7  Installing Apache, PHP and participant tools..."
export DEBIAN_FRONTEND=noninteractive
apt-get update -y
apt-get install -y apache2 libapache2-mod-php php wget curl net-tools iproute2 \
                   lsof vim less tar unzip ca-certificates

echo "[*] 7/7  Deploying the GreenLeaf site + staging backups..."
install -d -m 2775 /var/www/greenleaf
cp -r "$HERE/site/." /var/www/greenleaf/
# web root group-writable by 'user' so defenders can RESTORE without root:
groupadd -f webadmin
usermod -aG webadmin user
chown -R www-data:webadmin /var/www/greenleaf
find /var/www/greenleaf -type d -exec chmod 2775 {} \;
find /var/www/greenleaf -type f -exec chmod 0664 {} \;
# recovery backups OUT of web root, readable by 'user':
install -d -m 755 /opt/greenleaf/backups
cp -r "$HERE/backups/." /opt/greenleaf/backups/
chgrp -R webadmin /opt/greenleaf/backups
chmod -R g+rX /opt/greenleaf/backups

# enable the vhost
install -m 644 "$HERE/apache/greenleaf.conf" /etc/apache2/sites-available/greenleaf.conf
a2dissite 000-default >/dev/null 2>&1 || true
a2ensite greenleaf   >/dev/null
systemctl reload apache2

echo
echo "=================================================================="
echo " WEB SERVER READY."
echo "   Site:        http://10.0.50.10/   (and via DNS: http://greenleaf.com/)"
echo "   Login:       admin / admin  -> /dashboard.html   (only valid cred)"
echo "   Defender:    from step ->  ssh web   (user, key-only)"
echo "   IR tool:     sudo grn help"
echo "   Backups:     /opt/greenleaf/backups   (partial, for restore)"
echo "=================================================================="
