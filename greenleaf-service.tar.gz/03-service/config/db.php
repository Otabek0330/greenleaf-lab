<?php
// GreenLeaf dashboards — database connection settings.
// (Day-1: the attacker reads this file to obtain the DB credentials, then runs
//  mysqldump of the 'greenleaf' database and exfiltrates it.)
$DB_HOST = 'localhost';
$DB_NAME = 'greenleaf';
$DB_USER = 'gl_app';
$DB_PASS = 'Gl_app!Prod2024';
