#!/usr/bin/env bash
#
# grn — GreenLeaf scoped incident-response tool
# Installed to /opt/greenleaf/grn , owned root:root, mode 0755 (NOT writable by 'user').
# 'user' runs it via:  sudo grn <subcommand> ...
#
# It lets defenders remove ATTACKER artifacts (non-root shells, backdoor users,
# cron, dropped files) while REFUSING to touch root, protected service accounts,
# or the organizers' reporting agent. This is the mechanism behind the
# "teams can remediate but cannot become root / cannot kill the agent" design.
#
set -euo pipefail

# ---- protected lists (edit to match the build) -----------------------------
PROTECTED_USERS="root cbu user svc mysql www-data daemon bin sys sync nobody sshd systemd-network systemd-resolve messagebus syslog _apt"
AGENT_NAME="grn-agent"                       # the root reporting agent's process/unit name
PROTECTED_PATH_PREFIXES="/opt/greenleaf /etc/systemd /usr /bin /sbin /lib /lib64 /boot /proc /sys /run/systemd"
# ---------------------------------------------------------------------------

die(){ echo "grn: $*" >&2; exit 1; }
is_protected_user(){ for u in $PROTECTED_USERS; do [[ "$1" == "$u" ]] && return 0; done; return 1; }
is_protected_path(){ local rp; rp=$(readlink -f -- "$1" 2>/dev/null || echo "$1")
  for p in $PROTECTED_PATH_PREFIXES; do [[ "$rp" == "$p" || "$rp" == "$p/"* ]] && return 0; done; return 1; }

usage(){ cat <<U
grn — scoped incident-response tool (run with sudo)
  sudo grn kill <pid>            kill a NON-root process (e.g. a reverse shell)
  sudo grn deluser <name>        remove a backdoor account (not root/service accts)
  sudo grn rmfile <path>         delete a dropped file (not under system dirs)
  sudo grn cronclear <user>      wipe a user's crontab (not root/service accts)
  sudo grn help
Refuses anything touching root, the protected service accounts, or the agent.
U
}

cmd="${1:-help}"; shift || true
case "$cmd" in
  kill)
    pid="${1:-}"; [[ "$pid" =~ ^[0-9]+$ ]] || die "usage: grn kill <pid>"
    [[ "$pid" -eq 1 ]] && die "refusing to kill PID 1"
    owner=$(ps -o user= -p "$pid" 2>/dev/null | tr -d ' ') || die "no such pid"
    [[ -z "$owner" ]] && die "no such pid"
    [[ "$owner" == "root" ]] && die "refusing: PID $pid is root-owned (agent/system are protected)"
    cmdline=$(ps -o command= -p "$pid" 2>/dev/null || true)
    [[ "$cmdline" == *"$AGENT_NAME"* ]] && die "refusing: that is the reporting agent"
    kill -9 "$pid" && echo "killed pid $pid (was $owner: $cmdline)"
    ;;
  deluser)
    name="${1:-}"; [[ -n "$name" ]] || die "usage: grn deluser <name>"
    is_protected_user "$name" && die "refusing: '$name' is protected"
    id "$name" &>/dev/null || die "no such user"
    pkill -9 -u "$name" 2>/dev/null || true
    userdel -r "$name" 2>/dev/null || userdel "$name"
    echo "removed user '$name'"
    ;;
  rmfile)
    path="${1:-}"; [[ -n "$path" ]] || die "usage: grn rmfile <path>"
    is_protected_path "$path" && die "refusing: '$path' is under a protected system dir"
    [[ -e "$path" ]] || die "no such file"
    rm -rf -- "$path" && echo "removed '$path'"
    ;;
  cronclear)
    name="${1:-}"; [[ -n "$name" ]] || die "usage: grn cronclear <user>"
    is_protected_user "$name" && die "refusing: '$name' is protected"
    crontab -r -u "$name" 2>/dev/null && echo "cleared crontab for '$name'" || echo "no crontab for '$name'"
    ;;
  help|*) usage ;;
esac
