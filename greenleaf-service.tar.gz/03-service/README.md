# GreenLeaf — SERVICE server build (10.0.50.20)

Copy this `03-service/` folder onto the service VM, then:

1. Edit `setup-service.sh` → paste the step **public key** into `STEP_PUBKEY='...'`
   (same key you used on web). Leave `APPLY_SUDO_LAYER="yes"` to install grn now.
2. `sudo bash setup-service.sh`   (use `bash` — the +x bit may not survive transfer)

## What it builds
- **svc** account: runs the dashboards + webmail, and is the account the Day-1
  web→service pivot lands on (non-root, so its shell/persistence are removable).
- **user**: the exercise defender (key-only via the step key); **cbu** untouched.
- **sshd** hardened to key-only (disables password SSH for everyone incl. cbu —
  use the VMware console for admin, or give cbu a key).
- **Apache runs as svc** serving two sites:
  - `:80`   dashboards      → http://10.0.50.20/   (client / merchant / employee)
  - `:8080` webmail         → http://10.0.50.20:8080/  (mail.greenleaf.com:8080 via DNS)
    login **j.smith@greenleaf.com / GreenLeaf2024**; the inbox holds the Day-2
    phishing email from **supp0rt@chr0me.com** ("Update Chrome"). Not attacked.
- **MySQL** `greenleaf` DB (500 customers w/ names, emails, **MD5** passwords,
  phones, addresses + 1,500 orders) — the **Day-1 exfil target**, bound to
  127.0.0.1 only. App creds in `/var/www/greenleaf-dashboards/config/db.php`
  (not servable over HTTP; the attacker reads it from disk to run mysqldump).
- **grn** + scoped sudoers (if enabled) — same remediation model as web.
- **Pivot key** generated: `svc` trusts it; the private key is parked at
  `/root/greenleaf_pivot` for when we wire the attacker.

## Planted findings living here (teams flag these during the exercise)
- Customer passwords stored as **unsalted MD5** (weak hashing).
- **Plaintext DB credentials** in the app config file.
- The web→service SSH pivot trust (lateral-movement path).

## Notes for the attacker/orchestration stage (so detection works)
- The simulated Day-1 dump should **stage the mysqldump output on disk readable**
  (e.g. /tmp) before exfil, so defenders can find it and see the stolen PII + the
  MD5 hashes. We'll set that in the attacker scripts.
- DB app creds file is `svc`-readable by design; detection of the theft comes from
  the SSH pivot (auth log), the dump command, and the exfil connection.

## Account model recap
`cbu` = setup/admin · `svc` = app + pivot-landing (non-root) · `user` = defender (key-only)
