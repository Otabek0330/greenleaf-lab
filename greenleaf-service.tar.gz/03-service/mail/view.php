<?php
session_start();
if (empty($_SESSION['auth'])) { header('Location: /'); exit; }
$emails = require __DIR__.'/data/emails.php';
$id = (int)($_GET['id']??0);
if (!isset($emails[$id])) { header('Location: /'); exit; }
$m = $emails[$id];
?><!doctype html><html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?php echo htmlspecialchars($m['subj']);?> — GreenLeaf Mail</title>
<link rel="stylesheet" href="/assets/css/mail.css">
<link rel="icon" type="image/png" href="/assets/img/favicon.png"></head><body>
<header class="mtop"><a class="brand" href="/"><img class="logo-mark" src="/assets/img/logo-mark.png" alt=""><span>GreenLeaf Mail</span></a>
  <div class="acct">j.smith@greenleaf.com · <a href="/logout.php">Sign out</a></div></header>
<div class="mwrap single">
  <a class="back" href="/">&larr; Back to inbox</a>
  <div class="msg">
    <h1><?php echo htmlspecialchars($m['subj']);?></h1>
    <div class="msgmeta"><b><?php echo htmlspecialchars($m['from']);?></b>
      &lt;<?php echo htmlspecialchars($m['addr']);?>&gt; <span class="mdate"><?php echo htmlspecialchars($m['date']);?></span></div>
    <div class="msgbody"><?php echo $m['body']; // trusted generative content ?></div>
    <?php if($m['attach']): ?><div class="atts"><?php foreach($m['attach'] as $a): ?>
      <span class="att">&#128206; <?php echo htmlspecialchars($a);?></span><?php endforeach; ?></div><?php endif; ?>
  </div>
</div></body></html>
