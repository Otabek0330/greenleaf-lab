<?php
session_start();
$MAIL_USER='j.smith@greenleaf.com';
$MAIL_PASS='GreenLeaf2024';
$err='';
if ($_SERVER['REQUEST_METHOD']==='POST') {
    if (($_POST['email']??'')===$MAIL_USER && ($_POST['password']??'')===$MAIL_PASS) {
        $_SESSION['auth']=true; header('Location: /'); exit;
    }
    $err='Incorrect email or password.';
}
if (empty($_SESSION['auth'])) {
    ?><!doctype html><html lang="en"><head><meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>GreenLeaf Mail — Sign in</title>
    <link rel="stylesheet" href="/assets/css/mail.css">
    <link rel="icon" type="image/png" href="/assets/img/favicon.png"></head>
    <body class="loginbg"><div class="card login">
      <img class="logo-full" src="/assets/img/logo-full.png" alt="GreenLeaf">
      <h1>GreenLeaf Mail</h1>
      <?php if($err) echo '<p class="err">'.$err.'</p>'; ?>
      <form method="POST" class="form">
        <label>Email<input type="email" name="email" value="j.smith@greenleaf.com" required></label>
        <label>Password<input type="password" name="password" required></label>
        <button class="btn btn-primary wide">Sign in</button>
      </form>
    </div></body></html><?php
    exit;
}
$emails = require __DIR__.'/data/emails.php';
?><!doctype html><html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Inbox — GreenLeaf Mail</title>
<link rel="stylesheet" href="/assets/css/mail.css">
<link rel="icon" type="image/png" href="/assets/img/favicon.png"></head><body>
<header class="mtop"><a class="brand" href="/"><img class="logo-mark" src="/assets/img/logo-mark.png" alt=""><span>GreenLeaf Mail</span></a>
  <div class="acct">j.smith@greenleaf.com · <a href="/logout.php">Sign out</a></div></header>
<div class="mwrap">
  <aside class="mside"><a class="active" href="/">Inbox <span class="count"><?php echo count($emails);?></span></a>
    <a href="#">Starred</a><a href="#">Sent</a><a href="#">Drafts</a><a href="#">Spam</a><a href="#">Trash</a></aside>
  <main class="mlist">
    <?php foreach($emails as $id=>$m): ?>
    <a class="mrow <?php echo $m['unread']?'unread':'';?>" href="/view.php?id=<?php echo $id;?>">
      <span class="mfrom"><?php echo htmlspecialchars($m['from']);?></span>
      <span class="msubj"><?php echo htmlspecialchars($m['subj']);?>
        <?php if($m['attach']) echo '<span class="clip">&#128206;</span>';?></span>
      <span class="mprev"><?php echo htmlspecialchars($m['preview']);?></span>
      <span class="mdate"><?php echo htmlspecialchars($m['date']);?></span>
    </a>
    <?php endforeach; ?>
  </main>
</div></body></html>
