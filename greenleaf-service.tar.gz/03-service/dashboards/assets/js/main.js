// GreenLeaf — cosmetic front-end only.
document.querySelectorAll('a[href^="/#"]').forEach(function(a){
  a.addEventListener('click',function(e){
    var id=a.getAttribute('href').slice(2);
    var el=document.getElementById(id);
    if(el){e.preventDefault();el.scrollIntoView({behavior:'smooth'});}
  });
});
