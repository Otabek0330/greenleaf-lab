#!/usr/bin/env bash
#
# GreenLeaf exercise — SERVICE SERVER build  (run on the SERVICE VM, 10.0.50.20)
# Run with sudo:   sudo bash setup-service.sh
# Copy this whole 03-service/ folder onto the box first (e.g. /home/cbu/03-service).
#
# Accounts on this server:
#   cbu  = your setup/admin account (already exists; untouched)
#   svc  = app service account — runs the dashboards + webmail, and is the
#          account the web->service pivot key lands on (non-root, removable shell)
#   user = exercise DEFENDER account (key-only, via the step key)
#
# Hosts:
#   :80    dashboards     (http://10.0.50.20/)
#   :8080  webmail        (http://mail.greenleaf.com:8080/  -> j.smith mailbox)
#   MySQL  greenleaf DB   (generative PII; Day-1 exfil target; 127.0.0.1 only)
#
set -euo pipefail
[[ $EUID -eq 0 ]] || { echo "Run with sudo."; exit 1; }
HERE="$(cd "$(dirname "$0")" && pwd)"

# ======== EDIT THESE TWO LINES ========
STEP_PUBKEY='PASTE_THE_STEP_PUBLIC_KEY_HERE'    # ssh-ed25519 AAAA... greenleaf-jump
APPLY_SUDO_LAYER="yes"                           # yes = install grn + scoped sudoers
# ======================================
[[ "$STEP_PUBKEY" == PASTE_* ]] && { echo "Edit setup-service.sh: paste STEP_PUBKEY first."; exit 1; }

echo "[*] 1/10  Creating the 'svc' app/service account..."
id svc &>/dev/null || useradd --create-home --home-dir /home/svc --shell /bin/bash svc
passwd -l svc >/dev/null 2>&1 || true          # no password; key-only

echo "[*] 2/10  Creating the exercise defender account 'user'..."
id user &>/dev/null || adduser --disabled-password --gecos "GreenLeaf Analyst" user

echo "[*] 3/10  Installing the step public key for 'user'..."
install -d -m 700 /home/user/.ssh
printf '%s\n' "$STEP_PUBKEY" > /home/user/.ssh/authorized_keys
chmod 600 /home/user/.ssh/authorized_keys
chown -R user:user /home/user/.ssh

echo "[*] 4/10  Hardening sshd (key-only, no password, no root)..."
#   NOTE: disables password SSH for everyone (cbu included). Console stays available.
install -d -m 755 /etc/ssh/sshd_config.d
cat > /etc/ssh/sshd_config.d/greenleaf.conf <<'SSHD'
PasswordAuthentication no
PubkeyAuthentication yes
PermitRootLogin no
KbdInteractiveAuthentication no
SSHD
systemctl reload ssh 2>/dev/null || systemctl reload sshd 2>/dev/null || service ssh reload

echo "[*] 5/10  Installing Apache, PHP, MySQL and tools..."
export DEBIAN_FRONTEND=noninteractive
apt-get update -y
apt-get install -y apache2 libapache2-mod-php php php-mysql mysql-server \
                   wget curl net-tools iproute2 lsof vim less tar unzip ca-certificates

echo "[*] 6/10  Loading the generative customer database into MySQL..."
systemctl enable --now mysql
mysql < "$HERE/sql/greenleaf_db.sql"
echo "    rows: $(mysql -N -e 'SELECT COUNT(*) FROM greenleaf.customers;')"

echo "[*] 7/10  Making Apache run as 'svc' + enabling port 8080..."
sed -i 's/^export APACHE_RUN_USER=.*/export APACHE_RUN_USER=svc/'  /etc/apache2/envvars
sed -i 's/^export APACHE_RUN_GROUP=.*/export APACHE_RUN_GROUP=svc/' /etc/apache2/envvars
grep -q '^Listen 8080' /etc/apache2/ports.conf || echo 'Listen 8080' >> /etc/apache2/ports.conf

echo "[*] 8/10  Deploying the dashboards (:80), webmail (:8080) and DB config..."
install -d -m 755 /var/www/greenleaf-dashboards /var/www/greenleaf-mail
cp -r "$HERE/dashboards/." /var/www/greenleaf-dashboards/
cp -r "$HERE/mail/."       /var/www/greenleaf-mail/
install -d -m 750 /var/www/greenleaf-dashboards/config
install -m 640 "$HERE/config/db.php" /var/www/greenleaf-dashboards/config/db.php
chown -R svc:svc /var/www/greenleaf-dashboards /var/www/greenleaf-mail
install -m 644 "$HERE/apache/dashboards.conf" /etc/apache2/sites-available/dashboards.conf
install -m 644 "$HERE/apache/mail.conf"       /etc/apache2/sites-available/mail.conf
a2dissite 000-default >/dev/null 2>&1 || true
a2ensite dashboards mail >/dev/null
systemctl restart apache2

echo "[*] 9/10  Creating the web->service pivot key (the Day-1 lateral-movement trust)..."
if [[ ! -f /root/greenleaf_pivot ]]; then
  ssh-keygen -t ed25519 -N "" -C "web-to-service" -f /root/greenleaf_pivot
fi
install -d -m 700 /home/svc/.ssh
grep -q "web-to-service" /home/svc/.ssh/authorized_keys 2>/dev/null || \
  cat /root/greenleaf_pivot.pub >> /home/svc/.ssh/authorized_keys
chmod 600 /home/svc/.ssh/authorized_keys
chown -R svc:svc /home/svc/.ssh

echo "[*] 10/10  Exercise privilege layer (grn + scoped sudo)..."
if [[ "$APPLY_SUDO_LAYER" == "yes" ]]; then
  usermod -aG adm user
  install -d -m 755 /opt/greenleaf
  install -o root -g root -m 0755 "$HERE/grn-ir-tool.sh" /opt/greenleaf/grn
  ln -sf /opt/greenleaf/grn /usr/local/bin/grn
  install -o root -g root -m 0440 "$HERE/sudoers-greenleaf-user" /etc/sudoers.d/greenleaf-user
  visudo -cf /etc/sudoers.d/greenleaf-user >/dev/null && echo "    sudoers OK"
fi

echo
echo "=================================================================="
echo " SERVICE SERVER READY."
echo "   Dashboards:  http://10.0.50.20/"
echo "   Webmail:     http://10.0.50.20:8080/   (mail.greenleaf.com:8080 via DNS)"
echo "                login: j.smith@greenleaf.com / GreenLeaf2024"
echo "   Database:    MySQL 'greenleaf' (customers+orders) on 127.0.0.1"
echo "                app creds live in /var/www/greenleaf-dashboards/config/db.php"
echo "   From step:   ssh service   (as user, key-only)"
echo "------------------------------------------------------------------"
echo " PIVOT TRUST (web -> service) is half-built: svc now trusts the pivot key."
echo "   The PRIVATE key is parked at  /root/greenleaf_pivot  (keep it)."
echo "   We will place it on the web server when we wire up the attacker"
echo "   (it is only used by the simulated Day-1 lateral movement)."
echo "=================================================================="
