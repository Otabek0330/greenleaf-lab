#!/usr/bin/env bash
#
# GreenLeaf exercise — SECURITY / SIEM server (10.0.50.50)  —  sudo bash setup-security.sh
# Elasticsearch + Kibana (security disabled for the lab). Ingests logs from the
# proxy (Squid), firewall (iptables) and the Windows workstation (Winlogbeat).
# Teams open Kibana at http://10.0.50.50:5601 from the Windows workstation browser.
# NOT attacked.
#
set -euo pipefail
[[ $EUID -eq 0 ]] || { echo "Run with sudo."; exit 1; }

# ======== EDIT THIS ========
STEP_PUBKEY='PASTE_THE_STEP_PUBLIC_KEY_HERE'
# ===========================
[[ "$STEP_PUBKEY" == PASTE_* ]] && { echo "Paste STEP_PUBKEY first."; exit 1; }
SELF_IP='10.0.50.50'

echo "[*] 1/8  Defender account 'user' + step key + hardened sshd..."
id user &>/dev/null || adduser --disabled-password --gecos "GreenLeaf Analyst" user
install -d -m 700 /home/user/.ssh
printf '%s\n' "$STEP_PUBKEY" > /home/user/.ssh/authorized_keys
chmod 600 /home/user/.ssh/authorized_keys; chown -R user:user /home/user/.ssh
install -d -m 755 /etc/ssh/sshd_config.d
printf 'PasswordAuthentication no\nPubkeyAuthentication yes\nPermitRootLogin no\nKbdInteractiveAuthentication no\n' \
  > /etc/ssh/sshd_config.d/greenleaf.conf
systemctl reload ssh 2>/dev/null || systemctl reload sshd 2>/dev/null || true

echo "[*] 2/8  Kernel tuning for Elasticsearch (vm.max_map_count)..."
printf 'vm.max_map_count=262144\n' > /etc/sysctl.d/99-elastic.conf
sysctl -w vm.max_map_count=262144 >/dev/null

echo "[*] 3/8  Add Elastic 8.x APT repo..."
export DEBIAN_FRONTEND=noninteractive
apt-get update -y && apt-get install -y curl gnupg apt-transport-https vim less
curl -fsSL https://artifacts.elastic.co/GPG-KEY-elasticsearch \
  | gpg --dearmor -o /usr/share/keyrings/elastic-keyring.gpg
echo "deb [signed-by=/usr/share/keyrings/elastic-keyring.gpg] https://artifacts.elastic.co/packages/8.x/apt stable main" \
  > /etc/apt/sources.list.d/elastic-8.x.list
apt-get update -y

echo "[*] 4/8  Install Elasticsearch + Kibana..."
apt-get install -y elasticsearch kibana

echo "[*] 5/8  Configure Elasticsearch (single-node, security OFF, listen on LAN)..."
[[ -f /etc/elasticsearch/elasticsearch.yml.orig ]] || cp /etc/elasticsearch/elasticsearch.yml /etc/elasticsearch/elasticsearch.yml.orig
cat > /etc/elasticsearch/elasticsearch.yml <<CONF
cluster.name: greenleaf-siem
node.name: security
path.data: /var/lib/elasticsearch
path.logs: /var/log/elasticsearch
network.host: 0.0.0.0
http.port: 9200
discovery.type: single-node
xpack.security.enabled: false
xpack.security.enrollment.enabled: false
CONF
# heap: ~40% of RAM, clamped to [1g, 2g]
MEM_MB=$(free -m | awk '/^Mem:/{print $2}'); HEAP=$(( MEM_MB * 40 / 100 ))
(( HEAP < 1024 )) && HEAP=1024; (( HEAP > 2048 )) && HEAP=2048
printf -- "-Xms%sm\n-Xmx%sm\n" "$HEAP" "$HEAP" > /etc/elasticsearch/jvm.options.d/heap.options
echo "    ES heap = ${HEAP}m"

echo "[*] 6/8  Configure Kibana (listen on LAN, no auth)..."
[[ -f /etc/kibana/kibana.yml.orig ]] || cp /etc/kibana/kibana.yml /etc/kibana/kibana.yml.orig
cat > /etc/kibana/kibana.yml <<CONF
server.host: "0.0.0.0"
server.port: 5601
server.publicBaseUrl: "http://${SELF_IP}:5601"
elasticsearch.hosts: ["http://localhost:9200"]
CONF

echo "[*] 7/8  Start Elasticsearch, then Kibana..."
systemctl daemon-reload
systemctl enable elasticsearch kibana >/dev/null
systemctl restart elasticsearch
printf "    waiting for Elasticsearch"
for i in $(seq 1 60); do
  curl -s http://localhost:9200 >/dev/null 2>&1 && { echo " up."; break; }
  printf "."; sleep 3
done
systemctl restart kibana
echo "    Kibana starting (give it 1-2 min to come up at :5601)."

echo "[*] 8/8  Create the Squid ingest pipeline (parse proxy access.log)..."
curl -s -X PUT "http://localhost:9200/_ingest/pipeline/greenleaf-squid" \
  -H 'Content-Type: application/json' -d'
{
  "description": "Parse Squid access.log into ECS-ish fields",
  "processors": [
    { "grok": { "field": "message", "ignore_failure": true, "patterns": [
      "%{NUMBER:squid.ts} +%{NUMBER:squid.elapsed:long} %{IPORHOST:source.ip} %{WORD:squid.code}/%{NUMBER:http.response.status_code:long} %{NUMBER:http.response.bytes:long} %{WORD:http.request.method} %{NOTSPACE:url.original} %{NOTSPACE:squid.user} %{WORD:squid.hierarchy}/%{IPORHOST:destination.ip} %{NOTSPACE:http.response.mime_type}"
    ] } },
    { "date": { "field": "squid.ts", "formats": ["UNIX"], "target_field": "@timestamp", "ignore_failure": true } }
  ]
}' >/dev/null && echo "    pipeline greenleaf-squid created"
echo
echo "=================================================================="
echo " SIEM READY."
echo "   Elasticsearch: http://10.0.50.50:9200   (open, no auth)"
echo "   Kibana:        http://10.0.50.50:5601   (open; reach from the Windows box)"
echo "   Next: run the Filebeat commands on the PROXY and the FIREWALL"
echo "         (and Winlogbeat on Windows when that box is built)."
echo "   Check later:   curl http://10.0.50.50:9200/_cat/indices?v"
echo "=================================================================="
