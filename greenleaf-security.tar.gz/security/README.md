# GreenLeaf — Security / SIEM (10.0.50.50)
Elasticsearch + Kibana (security disabled for the lab). Ingests proxy, firewall
and (later) Windows logs. Teams use Kibana from the Windows workstation browser.

RAM: allocate 6 GB if you can (4 GB works but Kibana will be sluggish).

Run: edit setup-security.sh (step pubkey), `sudo bash setup-security.sh`.
  Elasticsearch -> http://10.0.50.50:9200   (open)
  Kibana        -> http://10.0.50.50:5601   (open; give it 1-2 min after start)

Then ship logs from the sources (commands below). After they run, in Kibana:
Discover -> data view "filebeat-*" shows proxy (squid, parsed) + firewall (iptables,
parsed); "winlogbeat-*" shows Windows events once that box is built.

Verify:  curl http://10.0.50.50:9200/_cat/indices?v   (expect filebeat-* with docs)

================================================================
## PROXY (10.0.50.30) — ship Squid access.log
================================================================
curl -fsSL https://artifacts.elastic.co/GPG-KEY-elasticsearch | sudo gpg --dearmor -o /usr/share/keyrings/elastic-keyring.gpg
echo "deb [signed-by=/usr/share/keyrings/elastic-keyring.gpg] https://artifacts.elastic.co/packages/8.x/apt stable main" | sudo tee /etc/apt/sources.list.d/elastic-8.x.list
sudo apt-get update && sudo apt-get install -y filebeat

sudo tee /etc/filebeat/filebeat.yml >/dev/null <<'YML'
filebeat.inputs:
  - type: filestream
    id: squid
    enabled: true
    paths: ["/var/log/squid/access.log"]
    pipeline: greenleaf-squid
    fields: {log_source: squid}
    fields_under_root: true
output.elasticsearch:
  hosts: ["http://10.0.50.50:9200"]
setup.kibana:
  host: "http://10.0.50.50:5601"
setup.ilm.enabled: false
YML

sudo filebeat setup --index-management --dashboards
sudo systemctl enable --now filebeat

================================================================
## FIREWALL (10.0.50.1) — ship iptables logs (parsed by the iptables module)
================================================================
curl -fsSL https://artifacts.elastic.co/GPG-KEY-elasticsearch | sudo gpg --dearmor -o /usr/share/keyrings/elastic-keyring.gpg
echo "deb [signed-by=/usr/share/keyrings/elastic-keyring.gpg] https://artifacts.elastic.co/packages/8.x/apt stable main" | sudo tee /etc/apt/sources.list.d/elastic-8.x.list
sudo apt-get update && sudo apt-get install -y filebeat

sudo tee /etc/filebeat/filebeat.yml >/dev/null <<'YML'
filebeat.config.modules:
  path: ${path.config}/modules.d/*.yml
  reload.enabled: false
output.elasticsearch:
  hosts: ["http://10.0.50.50:9200"]
setup.kibana:
  host: "http://10.0.50.50:5601"
setup.ilm.enabled: false
YML

sudo filebeat modules enable iptables
sudo tee /etc/filebeat/modules.d/iptables.yml >/dev/null <<'YML'
- module: iptables
  log:
    enabled: true
    var.paths: ["/var/log/greenleaf-firewall.log"]
    var.input: file
YML

sudo filebeat setup --index-management --pipelines --modules iptables --dashboards
sudo systemctl enable --now filebeat

## Note: Filebeat runs as root, so it reads the protected logs fine. Logs appear
## once there is traffic (browse through the proxy; forwarded traffic across the
## firewall fills in fully once the WAN/Kali exist).
