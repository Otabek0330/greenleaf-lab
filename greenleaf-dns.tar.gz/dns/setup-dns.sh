#!/usr/bin/env bash
#
# GreenLeaf exercise — DNS SERVER build (10.0.50.5)  —  run with: sudo bash setup-dns.sh
# dnsmasq authoritative for GreenLeaf + attacker domains. NOT attacked; teams can
# reach it and read its query log (a forensic source showing attacker-domain lookups).
#
set -euo pipefail
[[ $EUID -eq 0 ]] || { echo "Run with sudo."; exit 1; }

# ======== EDIT THESE ========
STEP_PUBKEY='PASTE_THE_STEP_PUBLIC_KEY_HERE'    # ssh-ed25519 AAAA... greenleaf-jump
ATTACKER_IP='203.0.113.10'                       # Kali on the WAN (behind the firewall)
WEB_IP='10.0.50.10'; SERVICE_IP='10.0.50.20'
# ============================
[[ "$STEP_PUBKEY" == PASTE_* ]] && { echo "Paste STEP_PUBKEY first."; exit 1; }

echo "[*] 1/5  Defender account 'user' + step key..."
id user &>/dev/null || adduser --disabled-password --gecos "GreenLeaf Analyst" user
install -d -m 700 /home/user/.ssh
printf '%s\n' "$STEP_PUBKEY" > /home/user/.ssh/authorized_keys
chmod 600 /home/user/.ssh/authorized_keys; chown -R user:user /home/user/.ssh

echo "[*] 2/5  Harden sshd (key-only)..."
install -d -m 755 /etc/ssh/sshd_config.d
printf 'PasswordAuthentication no\nPubkeyAuthentication yes\nPermitRootLogin no\nKbdInteractiveAuthentication no\n' \
  > /etc/ssh/sshd_config.d/greenleaf.conf
systemctl reload ssh 2>/dev/null || systemctl reload sshd 2>/dev/null || true

echo "[*] 3/5  Install dnsmasq..."
export DEBIAN_FRONTEND=noninteractive
# free port 53 from systemd-resolved if it is holding it
if systemctl is-active --quiet systemd-resolved; then
  mkdir -p /etc/systemd/resolved.conf.d
  printf '[Resolve]\nDNSStubListener=no\n' > /etc/systemd/resolved.conf.d/greenleaf.conf
  systemctl restart systemd-resolved || true
fi
apt-get update -y
apt-get install -y dnsmasq dnsutils vim less

echo "[*] 4/5  Write the zone (GreenLeaf + attacker domains)..."
cat > /etc/dnsmasq.d/greenleaf.conf <<CONF
# GreenLeaf DNS — authoritative for these names only; isolated (no upstream).
no-resolv
log-queries
log-facility=/var/log/dnsmasq.log
# --- GreenLeaf infrastructure ---
address=/greenleaf.com/${WEB_IP}
address=/www.greenleaf.com/${WEB_IP}
address=/mail.greenleaf.com/${SERVICE_IP}
address=/app.greenleaf.com/${SERVICE_IP}
# --- attacker infrastructure (all resolve to Kali on the WAN) ---
address=/chr0me.com/${ATTACKER_IP}
address=/chr0me-update.com/${ATTACKER_IP}
address=/cdn-chrome-sync.com/${ATTACKER_IP}
address=/update-delivery.net/${ATTACKER_IP}
address=/telemetry-cloud.net/${ATTACKER_IP}
address=/data-sync-api.com/${ATTACKER_IP}
CONF

echo "[*] 5/5  Start dnsmasq + make the query log readable by 'user'..."
touch /var/log/dnsmasq.log; chgrp adm /var/log/dnsmasq.log; chmod 640 /var/log/dnsmasq.log
usermod -aG adm user
systemctl enable --now dnsmasq
systemctl restart dnsmasq
echo
echo "=================================================================="
echo " DNS READY (10.0.50.5).  Test from any host that uses it:"
echo "   dig +short greenleaf.com        -> ${WEB_IP}"
echo "   dig +short mail.greenleaf.com   -> ${SERVICE_IP}"
echo "   dig +short chr0me.com           -> ${ATTACKER_IP}"
echo " Query log (forensic):  /var/log/dnsmasq.log   (readable by 'user')"
echo "=================================================================="
