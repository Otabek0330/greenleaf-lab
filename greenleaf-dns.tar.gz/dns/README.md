# GreenLeaf — DNS server (10.0.50.5)
Run: edit `setup-dns.sh` (paste step pubkey), then `sudo bash setup-dns.sh`.
dnsmasq, authoritative for GreenLeaf + attacker domains, isolated (no upstream),
query logging on. Resolves:
- greenleaf.com / www -> 10.0.50.10 (web)
- mail.greenleaf.com / app.greenleaf.com -> 10.0.50.20 (service)
- chr0me.com, chr0me-update.com, cdn-chrome-sync.com, update-delivery.net,
  telemetry-cloud.net, data-sync-api.com -> 203.0.113.10 (Kali on the WAN)
Query log: /var/log/dnsmasq.log (readable by `user`). Not attacked.
Change `ATTACKER_IP` at the top if the WAN addressing differs.
